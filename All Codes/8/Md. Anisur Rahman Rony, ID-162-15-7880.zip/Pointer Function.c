#include<stdio.h>
void add(int x, int y)
{
    printf("First value: %d\n",x);
    printf("Second value: %d\n",x);
    printf("Addition value: %d\n",x+y);
}
void main()
{
 int a,b;
 void (*ptr) (int,int);
 ptr=add;
 printf("Enter first number:\n");
 scanf ("%d",&a);
 printf("Enter second number:\n");
 scanf ("%d",&b);
 ptr(a,b);
}
