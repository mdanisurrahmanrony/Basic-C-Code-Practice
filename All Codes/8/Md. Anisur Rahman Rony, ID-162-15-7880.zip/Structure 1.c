#include<stdio.h>
struct cricketer
{
    int id;
    char name[20];
    char t_name[20];
    int age;
};
void main()
{
    struct cricketer c1={11,"Sakib","Bangladesh",25};
    struct cricketer c2={22,"Ms Dhoni","India",35};
    printf("The first employer's ID: %d\n",c1.id);
    printf("The first employer's Name: %s\n",c1.name);
    printf("The first employer's Team Name: %s\n",c1.t_name);
    printf("The first employer's age is: %d\n\n",c1.age);
    printf("The second employer's ID: %d\n",c2.id);
    printf("The second employer's Name: %s\n",c2.name);
    printf("The second employer's Team Name: %s\n",c2.t_name);
    printf("The second employer's age is: %d\n",c2.age);
}
