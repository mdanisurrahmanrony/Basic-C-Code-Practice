#include<stdio.h>
void swap(int *, int *);
void main()
{
    int a,b;
    printf("Enter value of a:\n");
    scanf("%d",&a);
    printf("Enter value of b:\n");
    scanf("%d",&b);
    printf("Values before swaping :\n");
    printf("Values of a=%d and b=%d\n",a,b);
    printf("Values after swapping: \n");
    swap (&a,&b);
    printf("Value of a=%d and b=%d\n",a,b);
}
void swap (int *x, int *y)
{
    int t;
    t=*x;
    *x=*y;
    *y=t;
}
