#include<stdio.h>
struct sellsman
{
  int age;
  int hieght;
  int n_sell;
};
void main()
{
    struct sellsman cell1;
}

