#include<stdio.h>
struct student
{
    char name[100];
    int marks;
    int roll;
};
void main()
{
struct student e[5];
int i,j;
for (i=0;i<5;++i)
{
    printf("Enter name: \n");
    scanf("%s",&e[i].name);
    printf("Enter roll: \n");
    scanf("%d",&e[i].roll);
    printf("Enter marsk:\n");
    for (j=0;j<5;j++)
    {
        scanf("%d",&e[j].marks);
    }
}
for(i=0;i<5;++i)
 {
    printf("Name: %s\n",e[i].name);
    printf("Roll: %d\n",e[i].roll);
    for (j=0;j<5;j++)
    {
        printf("Marks: %d",e[j].marks);
    }
}
}
