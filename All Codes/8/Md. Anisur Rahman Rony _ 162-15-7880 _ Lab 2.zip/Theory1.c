#include<stdio.h>
void main()
{
 int a;
printf ("Enter the number:\n");
scanf ("%d",&a);
if (a%3==0)
printf("The number is divisible by 3");
else
printf ("a is not divisible by 3");
}
