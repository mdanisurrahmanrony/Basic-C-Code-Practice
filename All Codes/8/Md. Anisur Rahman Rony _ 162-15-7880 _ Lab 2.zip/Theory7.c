#include<stdio.h>
void main()
{
    int i,j;
    for (i=0,j=0;j<25;j++,i--)
    {
        printf ("%d%d",i,j);
    }
}

