#include<stdio.h>
void main()
{
    int a,b,c,d,e,f;
    printf("Enter value of a,b,c");
    scanf("%d%d%d",&a,&b,&c);
    d= a==b && b==c;
    e= a==b || b==c;
    f= !e;
    printf("Logical AND is %d\n",d);
    printf("Logical OR is %d\n",e);
    printf("Logical NOT is %d",f);
}
