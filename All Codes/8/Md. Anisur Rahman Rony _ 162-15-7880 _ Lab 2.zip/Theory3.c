#include<stdio.h>
void main()
{
 int a,b,c,d;
 printf ("enter value gradually of a,b,c,d");
 scanf ("%d%d%d%d",&a,&b,&c,&d);
 if (a==b)
 printf ("a is equal to b");
 else if (a==c)
 printf ("a is equal to c");
 else if (a==d)
 printf ("a is equal to d");
 else
 printf ("number is not similar");
}

