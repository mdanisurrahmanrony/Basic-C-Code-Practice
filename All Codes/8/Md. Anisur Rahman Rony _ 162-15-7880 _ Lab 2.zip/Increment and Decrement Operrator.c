#include<stdio.h>
void main()
{
    int a,b,c,d,e;
    printf("Enter value of a");
    scanf("%d",&a);
    b=a++;
    c=++a;
    d=a--;
    e=--a;
    printf("Post Increment is %d\n",b);
    printf("Pre Increment is %d\n",c);
    printf("Post Decrement is %d\n",d);
    printf("Pre Decrement is %d",e);


}
