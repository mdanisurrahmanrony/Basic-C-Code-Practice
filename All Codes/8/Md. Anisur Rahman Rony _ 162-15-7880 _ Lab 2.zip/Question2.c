#include<stdio.h>
void main()
{
    int i,j,sum_of_odd=0,sum_of_even=0,x;
    for(i=1,j=2;i<=50;i+=2,j+=2)
    {
        sum_of_odd+=i;
        sum_of_even+=j;
    }
    printf ("Sum of odd number is %d\n",sum_of_odd);
    printf ("Sum of even number is %d\n",sum_of_even);
    if (sum_of_odd>sum_of_even)
    printf ("sum of odd is greater=%d\n");
    else if (sum_of_even>sum_of_odd)
    printf ("sum of even is greater=%d");

    else
    printf ("both sum of odd and sum of even are equal");

}
