#include<stdio.h>
void main()
{
int a,b,larger;
a=100;
b=200;
larger= a>b ? a:b ;
printf("The larger value among the two is %d",larger);
}
